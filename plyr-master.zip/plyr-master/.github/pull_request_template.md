### Link to related issue (if applicable)

### Sumary of proposed changes

### Task list

- [ ] Tested on [supported browsers](https://github.com/sampotts/plyr#browser-support)
- [ ] Gulp build completed